<template>
  <q-card class="row">
    <q-input
      v-model.trim="$v.text.$model"
      class="col-2 q-ma-md"
      label="Teste"
      error-message="CNPJ é Obrigatório"/>

    <q-btn
      class="col-1 q-ma-md"
      color="secondary"
      label="Enviar" />
  </q-card>
</template>

<style>
</style>

<script>
import { required } from 'vuelidate/lib/validators'
export default {
  validations () {
    return {
      text: { required }
    }
  },
  data () {
    return {
      text: ''
    }
  },
  methods: {
    enviar () {
      this.$v.$touch()
    }
  }
}
</script>
